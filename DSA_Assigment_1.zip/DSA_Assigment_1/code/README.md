# R-Tree-Implementation
C implementation of R Tree.

NOTE: The data must be put in code directory and the terminal's pwd must match ~/DSA_Assigment_1/code to get the correct output.

To compile the source code and generate executable file :- 
```console
user@host:~/DSA_Assigment_1/code$ gcc DSA_assignment_group_1.c
```
To run the executable file:- 
```console
user@host:~/DSA_Assigment_1/code$ ./a.out
```
The search function(excluding edges):- 
```console
search(rTree*tree,int minX,int maxX,int minY,int maxY)
```
The search function(including edges):- 
```console
searchIncludingEdges(rTree* tree,int minX,int maxX,int minY,int maxY)
```
The insert function(inserting a rectangle):- 
```console
insert(rTree *tree, int minX, int maxX, int minY, int maxY)
```
The insert function(inserting a point):- 
```console
insertPoint(rTree *tree, point p)
```
The insert function(inserting a polygon):- 
```console
insertPolygon(rTree *tree, polygon p,int size)
```
The traversal function(pre-order):- 
```console
preOrderTraversal(rTree *tree)
```
