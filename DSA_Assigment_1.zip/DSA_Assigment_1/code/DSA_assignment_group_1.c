/*
R-Tree Implementation - DSA Spring 2023 Assignment(Group 1) - BITS Pilani.

Authors: Dhyey Italiya - 2021A7PS1463P
         Saurabh Bhandari - 2021A7PS2412P
         Abir Abhyankar - 2021A7PS0523P
         Lakshit Sethi - 2021A7PS2434P
         Saksham Verma - 2021A7PS2414P
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define min(a, b) (a) < (b) ? (a) : (b)
#define max(a, b) (a) > (b) ? (a) : (b)
#define INF 1e9
#define yellow(x...)          \
    {                         \
        printf("\033[1;33m"); \
        printf(x);            \
        printf("\033[0m");    \
    }
#define red(x...)             \
    {                         \
        printf("\033[1;31m"); \
        printf(x);            \
        printf("\033[0m");    \
    }
#define green(x...)           \
    {                         \
        printf("\033[1;32m"); \
        printf(x);            \
        printf("\033[0m");    \
    }
// #define blue(x...) {printf("\033[1;34m");printf(x);printf("\033[0m");}
#define blue(x...)
// typedef enum
// {
//     false,
//     true
// } bool;

typedef struct pair pair;
struct pair // stores maximum and minimum limits of any dimension(In our case only 2-D)
{
    int minLimit;
    int maxLimit;
};

typedef struct MBR MBR; // Minimum bounding rectangle storing the limits in different dimensions.
struct MBR
{
    pair pairX;
    pair pairY;
};

typedef struct Node Node;
typedef struct Entry Entry;
struct Node // Node of the tree
{
    int noOfEntries;
    bool isLeaf;
    Entry **entries;
    Entry *parentEntry;
    Node *parent;
    int index; // for illustration purpose
};

struct Entry
{
    MBR *rectangle;
    Node *childNode;
};

typedef struct rTree rTree;
struct rTree
{
    int maxChildren; // M
    int minChildren; // m
    Entry *start;    // contains a pointer to root of the tree.
    Node *root;
    int no_of_nodes; // for illustration purpose
    int curr_no_of_nodes;
};

typedef struct point point;
typedef struct point *polygon;
struct point
{
    int x;
    int y;
};

MBR *createMBR(int minX, int maxX, int minY, int maxY);
Node *createNode(Entry *parentEntry, Node *parentNode, rTree *tree);
Entry *createEntry(MBR *rectangle, Node *child);
rTree *createRtree(int minchild, int maxchild);
void preOrderTraversal(rTree *tree);
void search(rTree *tree, int minX, int maxX, int minY, int maxY);
void insert(rTree *tree, int minX, int maxX, int minY, int maxY);
void insertPolygon(rTree *tree, point *pts, int n);
void insertPoint(rTree *tree, point pt);

void swap(int *a, int *b);
void printNode(Node *node);
void printEntry(Entry *Entry);
int findArea(MBR *rectangle);
MBR *findMBR(Node *currNode);
bool isOverlapping(MBR *rect1, MBR *rect2);
MBR *unionMBR(MBR *rect1, MBR *rect2);

//======================================================================
// R-Trees Functions
// Creates new MBR
MBR *createMBR(int minX, int maxX, int minY, int maxY)
{
    MBR *rectangle = (MBR *)malloc(sizeof(MBR));
    rectangle->pairX.minLimit = minX;
    rectangle->pairX.maxLimit = maxX;
    rectangle->pairY.minLimit = minY;
    rectangle->pairY.maxLimit = maxY;
    return rectangle;
}

// Creates new node
Node *createNode(Entry *parentEntry, Node *parent, rTree *tree)
{
    Node *node = (Node *)malloc(sizeof(Node));
    node->noOfEntries = 0;
    node->isLeaf = 0;
    node->parentEntry = parentEntry;
    node->parent = parent;
    node->entries = (Entry **)malloc((tree->maxChildren + 1) * (sizeof(Entry *)));
    node->index = tree->no_of_nodes++;
    tree->curr_no_of_nodes++;
    return node;
}

// Creates new entry
Entry *createEntry(MBR *rectangle, Node *child)
{
    Entry *entry = (Entry *)malloc(sizeof(Entry));
    entry->childNode = child;
    entry->rectangle = rectangle;
    return entry;
}

// Create new rTree
rTree *createRtree(int minchild, int maxchild)
{
    rTree *tree = (rTree *)malloc(sizeof(rTree));
    tree->minChildren = minchild;
    tree->maxChildren = maxchild;
    tree->start = (Entry *)malloc(sizeof(Entry));
    tree->start->rectangle = NULL;
    tree->no_of_nodes = 0;
    tree->curr_no_of_nodes = 0;
    tree->root = createNode(tree->start, NULL, tree);
    tree->root->isLeaf = 1;
    return tree;
}

//======================================================================
// Utility Functions

// Swaps two integer variables.
void swap(int *a, int *b)
{
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Print the details of an entry
void printEntry(Entry *Entry)
{
    MBR *MBR = Entry->rectangle;

    if (MBR == NULL)
    {
        return;
    }

    green("\t\tTop Right -> %d,%d\n", MBR->pairX.maxLimit, MBR->pairY.maxLimit);
    green("\t\tBottom Left -> %d,%d\n\n", MBR->pairX.minLimit, MBR->pairY.minLimit);

    return;
}

// Print the details of an entry, plainly
void printEntryPlain(Entry *Entry)
{
    MBR *MBR = Entry->rectangle;

    if (MBR == NULL)
    {
        return;
    }

    green("\t\t%d,%d;", MBR->pairX.maxLimit, MBR->pairY.maxLimit);
    green("\t%d,%d\n", MBR->pairX.minLimit, MBR->pairY.minLimit);

    return;
}

void printNode(Node *node)
{
    yellow("Entering Node %d\n", node->index);

    // print all the child nodes of the current node
    yellow("Child Nodes :- [ ");
    for (int i = 0; i < node->noOfEntries; i++)
    {
        if (node->entries[i] != NULL && node->entries[i]->childNode != NULL)
        {
            yellow("%d,", node->entries[i]->childNode->index);
        }
    }
    yellow("]\n");

    // print the entries of the current node
    for (int i = 0; i < node->noOfEntries; i++)
    {
        green("\tEntry %d\n", i);
        printEntry(node->entries[i]);
    }
    yellow("Exiting Node %d\n", node->index);
}

// Find the area of a rectangle
int findArea(MBR *rectangle)
{
    int length = rectangle->pairX.maxLimit - rectangle->pairX.minLimit;
    int breadth = rectangle->pairY.maxLimit - rectangle->pairY.minLimit;

    return length * breadth;
}

// Find the MBR of a node given all its entries
MBR *findMBR(Node *currNode)
{
    // to skip the dummy node in the beginning
    if (currNode->noOfEntries == 0)
    {
        return NULL;
    }

    // initialize the min and max values
    int minx = currNode->entries[0]->rectangle->pairX.minLimit;
    int miny = currNode->entries[0]->rectangle->pairY.minLimit;
    int maxx = currNode->entries[0]->rectangle->pairX.maxLimit;
    int maxy = currNode->entries[0]->rectangle->pairY.maxLimit;

    // find the min and max values
    for (int i = 1; i < currNode->noOfEntries; i++)
    {
        minx = min(minx, currNode->entries[i]->rectangle->pairX.minLimit);
        miny = min(miny, currNode->entries[i]->rectangle->pairY.minLimit);
        maxx = max(maxx, currNode->entries[i]->rectangle->pairX.maxLimit);
        maxy = max(maxy, currNode->entries[i]->rectangle->pairY.maxLimit);
    }

    // create the MBR and return it
    return createMBR(minx, maxx, miny, maxy);
}

// checks if two rectangles are overlapping
bool isOverlapping(MBR *rect1, MBR *rect2)
{
    if (rect1->pairX.minLimit >= rect2->pairX.maxLimit || rect1->pairX.maxLimit <= rect2->pairX.minLimit)
        return false;

    if (rect1->pairY.minLimit >= rect2->pairY.maxLimit || rect1->pairY.maxLimit <= rect2->pairY.minLimit)
        return false;

    return true;
}

// finds the union of two rectangles
MBR *unionMBR(MBR *rect1, MBR *rect2)
{
    int minx = min(rect1->pairX.minLimit, rect2->pairX.minLimit);
    int miny = min(rect1->pairY.minLimit, rect2->pairY.minLimit);
    int maxx = max(rect1->pairX.maxLimit, rect2->pairX.maxLimit);
    int maxy = max(rect1->pairY.maxLimit, rect2->pairY.maxLimit);

    return createMBR(minx, maxx, miny, maxy);
}

void insertPolygon(rTree *tree, polygon pts, int n)
{
    int minx = pts[0].x, maxx = pts[0].x, miny = pts[0].y, maxy = pts[0].y;
    for (int i = 1; i < n; i++)
    {
        minx = min(minx, pts[i].x);
        maxx = max(maxx, pts[i].x);
        miny = min(miny, pts[i].y);
        maxy = max(maxy, pts[i].y);
    }
    insert(tree, minx, maxx, miny, maxy);
}

void insertPoint(rTree *tree, point p)
{
    insert(tree, p.x, p.x, p.y, p.y);
}

//======================================================================
// Traversal Functions

// To traverse the tree in pre-order fashion
void preOrderTraversal_Utility(Node *currNode)
{
    // base case
    if (currNode == NULL)
    {
        return;
    }

    printNode(currNode);

    // recursively call the function for the child nodes
    for (int i = 0; i < currNode->noOfEntries; i++)
    {
        preOrderTraversal_Utility(currNode->entries[i]->childNode);
    }
    return;
}

// wrapper function for the traverse function
void preOrderTraversal(rTree *tree)
{
    printEntry(tree->start);
    preOrderTraversal_Utility(tree->root);
}

//======================================================================
// Search Functions

// recursive function to search for all entries that overlap with search_rect
void search_utility(Node *currNode, MBR *search_rect)
{
    // base case
    if (currNode == NULL)
    {
        return;
    }

    // if currNode is a leaf node, print all entries that overlap with search_rect
    if (currNode->isLeaf)
    {
        for (int i = 0; i < currNode->noOfEntries; i++)
        {
            if (isOverlapping(currNode->entries[i]->rectangle, search_rect))
            {
                printEntry(currNode->entries[i]);
            }
        }
        return;
    }

    // if currNode is not a leaf node, recursively call search_utility on all entries that overlap with search_rect
    for (int i = 0; i < currNode->noOfEntries; i++)
    {
        if (isOverlapping(currNode->entries[i]->rectangle, search_rect))
        {
            search_utility(currNode->entries[i]->childNode, search_rect);
        }
    }
}

// wrapper function for search_utility
void search(rTree *tree, int minX, int maxX, int minY, int maxY)
{
    blue("[Entering Search]\n");

    MBR *search_rect = createMBR(minX, maxX, minY, maxY);

    search_utility(tree->root, search_rect);

    blue("[Exiting Search]\n")
}

void searchIncludingEdges(rTree *tree, int minX, int maxX, int minY, int maxY)
{
    search(tree, minX - 1, maxX + 1, minY - 1, maxY + 1);
}
//======================================================================
// Insertion functions

// choose the most optimal leaf node to insert the new rectangle
Node *chooseLeaf(Node *currNode, MBR *targetRect)
{
    blue("[Entering chooseLeaf]\n");

    // if currNode is a leaf node, return it
    if (currNode->isLeaf)
    {
        return currNode;
    }

    int minArea = INF;
    int minIndex = 0;
    int minCurrArea = INF;

    // find the entry with the least area enlargement
    for (int i = 0; i < currNode->noOfEntries; i++)
    {
        // find area of the rectangle formed by union of the entry and the target rectangle
        int currArea = findArea(currNode->entries[i]->rectangle);
        MBR *newRect = unionMBR(currNode->entries[i]->rectangle, targetRect);
        int newArea = findArea(newRect);
        free(newRect);

        // find the difference in old area and the new area
        int diffArea = newArea - currArea;
        int minCurrArea = min(minCurrArea, currArea);

        // if the difference is less than the minimum difference, update the minimum difference and the index
        if ((diffArea < minArea) || (diffArea == minArea && currArea < minCurrArea))
        {
            minArea = diffArea;
            minIndex = i;
        }
    }

    blue("[Exiting chooseLeaf]\n");
    return chooseLeaf(currNode->entries[minIndex]->childNode, targetRect);
}

// pick group representative for splitting current node
void pickSeeds(Node *currNode, int *seed1, int *seed2)
{
    blue("[Picking seeds]\n");
    // store the max difference of two rectangles
    int maxDiff = -1;
    for (int i = 0; i < currNode->noOfEntries; i++)
    {
        for (int j = i + 1; j < currNode->noOfEntries; j++)
        {
            MBR *unionRect = unionMBR(currNode->entries[i]->rectangle, currNode->entries[j]->rectangle);

            // find the difference in area of the union rectangle and the sum of the areas of the two rectangles
            int diff = findArea(unionRect) - findArea(currNode->entries[i]->rectangle) - findArea(currNode->entries[j]->rectangle);
            free(unionRect);
            if (i == 0 && j == 1)
            {
                maxDiff = diff;
                *seed1 = i;
                *seed2 = j;
            }
            // if the difference is greater than the maximum difference, update the maximum difference and the seeds
            if (diff > maxDiff)
            {
                maxDiff = diff;
                *seed1 = i;
                *seed2 = j;
            }
        }
    }
    blue("[Exiting pickSeeds]\n");
    return;
}

// decide which entry to choose next, and which group to put it in
int pickNext(Node *currNode, Entry *group1, Entry *group2, bool *res)
{
    blue("[Entering pickNext]\n");

    int maxDiff = 0;
    int maxIndex = 0;

    MBR *g1rect = group1->rectangle;
    MBR *g2rect = group2->rectangle;

    for (int i = 0; i < currNode->noOfEntries; i++)
    {
        // find the difference in area of the new rectangle formed by union of the entry and the group rectangle of group1
        MBR *Rect1 = unionMBR(g1rect, currNode->entries[i]->rectangle);
        int diff1 = findArea(Rect1) - findArea(g1rect);
        free(Rect1);

        // find the difference in area of the new rectangle formed by union of the entry and the group rectangle of group2
        MBR *Rect2 = unionMBR(g2rect, currNode->entries[i]->rectangle);
        int diff2 = findArea(Rect2) - findArea(g2rect);
        free(Rect2);

        // find the difference between the two differences
        int diff = abs(diff1 - diff2);
        // condition and tie breakers for assigning the entry to a group
        if (diff > maxDiff)
        {
            maxDiff = diff;
            maxIndex = i;
            if (diff1 < diff2)
                *res = true;
            else if (diff1 > diff2)
                *res = false;
            else if (findArea(g1rect) < findArea(g2rect))
                *res = true;
            else if (findArea(g1rect) > findArea(g2rect))
                *res = false;
            else if (group1->childNode->noOfEntries < group2->childNode->noOfEntries)
                *res = true;
            else
                *res = false;
        }
    }

    blue("[Exiting pickNext]\n");
    return maxIndex;
}

// split the node into two groups
void quadraticSplit(Node *currNode, rTree *tree)
{
    blue("[Entering Split]\n");

    int seed1, seed2;

    // pick two entries to be the first elements of the groups
    pickSeeds(currNode, &seed1, &seed2);
    // printf("%d,%d\n",seed1,seed2);
    // create two new nodes to be the groups
    Node *group1 = createNode(NULL, currNode, tree);
    Node *group2 = createNode(NULL, currNode, tree);

    // if the current node is a leaf node, set the leaf flag of the groups
    if (currNode->isLeaf == true)
    {
        group1->isLeaf = true;
        group2->isLeaf = true;
        currNode->isLeaf = false;
    }
    // else set the leaf flag of the groups to false
    else
    {
        group1->isLeaf = false;
        group2->isLeaf = false;
    }

    // add the seeds to respective groups

    group1->noOfEntries = 1;
    group2->noOfEntries = 1;

    group1->entries[0] = currNode->entries[seed1];
    group2->entries[0] = currNode->entries[seed2];

    // remove the seeds from the current node
    currNode->entries[seed2] = currNode->entries[currNode->noOfEntries - 1];
    currNode->noOfEntries--;

    currNode->entries[seed1] = currNode->entries[currNode->noOfEntries - 1];
    currNode->noOfEntries--;

    // while the current node is not empty
    while (currNode->noOfEntries > 0)
    {
        // if one of the groups has maxChildren entries, add all the remaining entries to the other group
        if (group2->noOfEntries + currNode->noOfEntries == tree->minChildren)
        {
            for (int i = 0; i < currNode->noOfEntries; i++)
            {
                group2->entries[group2->noOfEntries] = currNode->entries[i];
                group2->noOfEntries++;
            }

            currNode->noOfEntries = 0;
            break;
        }
        else if (group1->noOfEntries + currNode->noOfEntries == tree->minChildren)
        {
            for (int i = 0; i < currNode->noOfEntries; i++)
            {
                group1->entries[group1->noOfEntries] = currNode->entries[i];
                group1->noOfEntries++;
            }

            currNode->noOfEntries = 0;
            break;
        }
        else
        {
            // pick the next entry to be added to a group, and the group to which it should be added
            bool group_flag;
            int index = pickNext(currNode, group1->entries[0], group2->entries[0], &group_flag);

            // add to group 1
            if (group_flag)
            {
                group1->entries[group1->noOfEntries] = currNode->entries[index];
                group1->noOfEntries++;
            }

            // add to group 2
            else
            {
                group2->entries[group2->noOfEntries] = currNode->entries[index];
                group2->noOfEntries++;
            }

            // remove the entry from the current node
            currNode->entries[index] = currNode->entries[currNode->noOfEntries - 1];
            currNode->noOfEntries--;
        }
    }
    for (int i = 0; i < group1->noOfEntries; i++)
    {
        if (group1->entries[i]->childNode != NULL)
            group1->entries[i]->childNode->parent = group1;
    }
    for (int i = 0; i < group2->noOfEntries; i++)
    {
        if (group2->entries[i]->childNode != NULL)
            group2->entries[i]->childNode->parent = group2;
    }
    // if the current node is the root node, create a new root node and add the groups as its children
    if (currNode->parent == NULL)
    {
        currNode->noOfEntries = 2;
        currNode->entries[0] = createEntry(findMBR(group1), group1);

        group1->parentEntry = currNode->entries[0];
        currNode->entries[1] = createEntry(findMBR(group2), group2);

        group2->parentEntry = currNode->entries[1];
        group1->parent = currNode;
        group2->parent = currNode;

        tree->root = currNode;
        currNode->isLeaf = false;
    }

    // else add the groups as entries to the parent node and remove the current node.
    else
    {
        currNode->parentEntry->childNode = group1;
        currNode->parentEntry->rectangle = findMBR(group1);

        currNode->parent->entries[currNode->parent->noOfEntries] = createEntry(findMBR(group2), group2);
        currNode->parent->noOfEntries++;

        group1->parent = currNode->parent;
        group1->parentEntry = currNode->parentEntry;

        group2->parentEntry = currNode->parent->entries[currNode->parent->noOfEntries - 1];
        group2->parent = currNode->parent;

        tree->curr_no_of_nodes--;
    }

    blue("[Exiting Split]\n");
}

// function to adjust the tree after insertion
void adjustTree(Node *currNode, rTree *tree)
{
    blue("[Entering Adjust]\n");

    if (currNode == NULL)
    {
        return;
    }

    // if the current node is the root node, set it as the root of the tree and return
    if (currNode->parent == NULL)
    {
        tree->root = currNode;
        return;
    }

    // else adjust the MBR of the parent node and check if it needs to be split
    Node *parent = currNode->parent;

    // update the MBR of the parent node
    MBR *newVal = findMBR(currNode);
    if (newVal)
        currNode->parentEntry->rectangle = newVal;

    // if the parent node needs to be split, split it and adjust the tree
    if (parent->noOfEntries > tree->maxChildren)
    {

        quadraticSplit(parent, tree);
        if (parent != tree->root)
            adjustTree(parent, tree);
        if (parent != tree->root)
        {
            free(parent);
        }
    }
    // else adjust the tree
    else
    {
        adjustTree(parent, tree);
    }

    blue("[Exiting Adjust]\n");
}

// insert a rectangle into the tree
void insert(rTree *tree, int minX, int maxX, int minY, int maxY)
{
    blue("[Entering Insert]\n");

    // create a rectangle and an entry for the rectangle
    MBR *rect = createMBR(minX, maxX, minY, maxY);
    Entry *entry = createEntry(rect, NULL);

    // choose the leaf node to which the entry should be added
    Node *currNode = chooseLeaf(tree->root, rect);

    // add the entry to the leaf node
    currNode->entries[currNode->noOfEntries] = entry;
    currNode->noOfEntries++;

    // if the leaf node needs to be split, split it
    if (currNode->noOfEntries > tree->maxChildren)
    {
        quadraticSplit(currNode, tree);
        adjustTree(currNode, tree);
        if (currNode->parent != NULL)
        {
            free(currNode);
        }
    }
    else
    {
        adjustTree(currNode, tree);
    }

    blue("[Exiting Insert]\n");
}

//==========================================================================
// Driver code

int main()
{
    rTree *tree = createRtree(2, 4);
    // read the input from the file
    FILE *fp = fopen("sample_data.txt", "r");
    while (!feof(fp))
    {
        int x1, y1;
        fscanf(fp, "%d %d", &x1, &y1);
        point pt = {x1, y1};
        insertPoint(tree, pt);
    }
    fclose(fp);
    printf("Number of nodes in the tree: %d\n", tree->curr_no_of_nodes);
    printf("Number of nodes created: %d\n", tree->no_of_nodes);
    printf("Starting search\n");
    searchIncludingEdges(tree, 0, 100, 0, 100);
    printf("Starting pre-order traversal\n");
    preOrderTraversal(tree);
    return 0;
}

//=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X=X
// END OF DOCUMENT//
